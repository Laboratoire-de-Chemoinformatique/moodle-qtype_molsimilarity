{ Rest server of the molsimilarity Moodle Plugin (https://github.com/Laboratoire-de-Chemoinformatique/moodle-qtype_molsimilarity)

  Copyright (C) 2022 Laboratoire de Chemoinformatique, UMR 7140 CNRS (http://infochim.u-strasbg.fr/)
  contact: Gilles Marcou g.marcou@unistra.fr

  This source is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free
  Software Foundation; either version 3 of the License, or (at your option)
  any later version.

  This code is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
  details.

  A copy of the GNU General Public License is available on the World Wide Web
  at <http://www.gnu.org/copyleft/gpl.html>. You can also obtain it by writing
  to the Free Software Foundation, Inc., 51 Franklin Street - Fifth Floor,
  Boston, MA 02110-1335, USA.
}

program rest_api_multi;

{$mode objfpc}{$H+}
uses
 {$IFDEF UNIX}cthreads,
  cmem,
 {$ENDIF}
  SysUtils,
  fphttpapp,
  httpdefs,
  httproute,
  fpjson,
  //jsonparser,
  Classes,
  BasicSDF, U_GRAPHES, unitAtomAndBondType, UnitMolecule, U_TYPE_GRAPHES,
  UnitFragment,
  ISIDA_descriptor,
  unit_api_tools,
  JsonTools,
  Dos,
  UnitXMLFrg, UnitAtomBase,
  Math,
  unit_JWT, unitIndigo,
  getopts;
var
  i: LongInt;
  textJWT, textPort, SubstrPort, Portnb: String;

  procedure jsonResponse(var res: TResponse; Data: string; httpCode: integer);
  begin
    res.Content := Data;
    res.Code := httpCode;
    res.ContentType := 'application/json';
    res.ContentLength := length(res.Content);
    res.SendContent;
  end;

  procedure timeEndpoint(req: TRequest; res: TResponse);
  var
    jObject: TJSONObject; // holds JSON data to be translated into a JSON object
  begin
    jObject := TJSONObject.Create;
    try
      jObject.Strings['time'] := TimeToStr(Time);
      res.Content := jObject.AsJSON; // output the data as a JSON formatted string
      jsonResponse(res, jObject.AsJSON, 200);
    finally
      jObject.Free;
    end;
  end;

  procedure greetingEndpoint(req: TRequest; res: TResponse);
  var
    jObject: TJSONObject;
  begin
    jObject := TJSONObject.Create;
    try
      jObject.Strings['greeting'] := 'Hello, ' + req.RouteParams['name'];
      res.Content := jObject.AsJSON;
      jsonResponse(res, jObject.AsJSON, 200);
    finally
      jObject.Free;
    end;
  end;

  procedure ISIDA(req: TRequest; res: TResponse);
  { Takes a JSON which contains two molecules encoded as molfiles (where the lineending are replaced by '\n') as input, returns the same Json, with a grade appended}
  const
    XMLFile = 't0t3l2u4FCUR.xml';
    logFile = 'errors_log.txt';
  var
    //headerValue, id, jObject: TJSONObject;
    //réponse et correction
    smol_student, smol_correction, smol_scaffold, srxn_scaffold: string;
    sStereo, suniqueid : string;
    mol_student, mol_correction, mol_scaffold: TStringList;
    mol_student_arom, mol_correction_arom, mol_scaffold_arom: TStringList;
    note, noteMax, noteScaffold: double;
    // Param fragmentor
    frag: TFragment;
    pitem: PDefFrg;
    totfraglst: TStringList;
    Parser: TJsonNode;
    xmlfrg: TXMLFrg;
    { pint: PInteger;
    desc: RDsc;      // Valeur du desc
    i: integer;
    mol: LRDsc;      // Liste de Desc décrivant une molécule}
    mol_data: LRDsc;
    molList: LRSMFv2; // Matrice de descripteurs
    stereo_student, stereo_correction: record_output;
    I, stereo_counter, max_stereo, httpCode, nbCorrection, molMax: longint;
    // Token cheking
    FCredential, FAuthorization, VOutput, AMethod, linetxt, AIP, SJWT: string;
    jObject: TJSONObject;
    f: TextFile;
    l: Text;
  begin
    {if FileExists('heap.trc') then
      DeleteFile('heap.trc');
    SetHeapTraceOutput('heap.trc');}
    // Check if JWT is needed.
    For i:=1 to ParamCount do
      begin
      if (ParamStr(i) = '--JWTNEEDED') then
      begin
        SJWT:= 'YES';
        break;
      end;
      end;

    if (SJWT = 'YES') then
    begin

    // JWT checker
    FCredential:= req.Authorization;
    AMethod := req.Method;
    AIP := req.RemoteAddress;

    // Read key Value.
    try
      AssignFile(f, 'JWTKEY.txt');
      Reset(f);
      readln(f, linetxt);
      FAuthorization:= linetxt;
      CloseFile(f);
    except
    end;

    if (not (JWTParse(FCredential, FAuthorization, AMethod, VOutput))) then
    begin
      jObject := TJSONObject.Create;
      httpCode := 401;
      jObject.Strings['success'] := 'False';
      jObject.Strings['reason'] := Format('You''re not authorized to enter. %s . Trying to connect from this ip: %s', [VOutput, AIP]);
      // Append to the log file;
      try
         Assign(l, logFile);
         Append(l);
         WriteLn(l, jObject.Strings['reason']);
         Close(l);
      except
        on E: EInOutError do
          writeln('File error. Elaboration: ', E.Message);
      end;
      res.Content := jObject.AsJSON;
      jsonResponse(res, jObject.AsJSON, httpCode);
      FreeAndNil(jObject);
      Abort;
    end;

    end;

    frag := TFragment.Create;
    // XML Reader
    try
       begin //Read the XML file witch contains the parameters for the fragmentor
         xmlfrg:=TXMLFrg.Create(XMLFile, True);
         xmlfrg.ReadFragmentations();
         while (not xmlfrg.stop) do
           begin
             pitem:=new(PDefFrg);
             xmlfrg.ReadFragmentation(pitem);
             frag.AddFragmentor(pitem^);
             xmlfrg.NextFragmentation;
           end;
           FreeAndNil(xmlfrg);
       end;
    except   // If there is no XML file to parameter the fragmentor, we use this Fragmentation (-t 3 -l 2 -u 4)    Add the atom count Fragmentation !!!!!!
       begin
         Exception.Create('WARNING: Cannot read Fragmentor XML file:' + XMLFile + ', using default fragmentation scheme: -t 3 -l 2 -u 4');
         new(pitem);
         InitDefFrg(pitem);
         pitem^.FrgType := 3;
         pitem^.lmin := 2;
         pitem^.lmax := 4;   // Instance pas pointeur
         pitem^.UseFormalCharge:=True;
         pitem^.UseRadical:=True;
         frag.AddFragmentor(pitem);    // on ajoute la méthode de fragmentation au fragmentor
         // Atom count fragmentation
         new(pitem);
         InitDefFrg(pitem);
         pitem^.FrgType := 0;
         pitem^.lmin := 0;
         pitem^.lmax := 0;
         pitem^.UseFormalCharge:=True;
         pitem^.UseRadical:=True;
         frag.AddFragmentor(pitem);
       end;
    end;

    // Fragmentation of the molecules

    molList := LRSMFv2.Create;

    begin
     // WriteLn(ExtractFilePath(ParamStr(0)) + XMLFile);

      Parser := TJsonNode.Create;
      Parser.Parse(req.Content); // Getting the json

      // Getting the mol from the JSON, and generating fragments

      smol_student := Parser.Find('student/mol').Value;
      mol_student := TStringList.Create;
      mol_student.Text := StringReplace(smol_student, '\n', Lineending,
        [rfReplaceAll, rfIgnoreCase]); // From string to Tstringlist

      mol_student_arom := aromatize_lp(mol_student);
      FreeAndNil(mol_student);

      frag.FrgReset; // purge le fragmentor des fragments générés pour la molécule précédente.
      frag.MolToFrgLst(mol_student_arom);  // Take the molfile and generates the fragments. Dictionnaire mot qui décrit le frg et pointeur vers une valeur
      totfraglst := frag.GetFrgLst;   // A row of the descriptor matrix

      molList.Add(LRDsc.Create);     // Contains the LRDsc objects
      mol_data := molList.Last as LRDsc;
      LRDsc_creation(totfraglst, mol_data);

      // Getting the mol from the JSON, and generating fragments (Correction).
      nbCorrection:= StrToInt(Parser.Find('corectopt/nbmol').Value);  // Check how many mol of correction

      mol_correction := TStringList.Create;
      for I := 1 to nbCorrection do
      begin
        smol_correction := Parser.Find('correction/mol_' + IntToStr(I)).Value;
        //mol_correction := TStringList.Create;
        mol_correction.Text := StringReplace(smol_correction, '\n',
          Lineending, [rfReplaceAll, rfIgnoreCase]);

        mol_correction_arom := aromatize_lp(mol_correction);
        mol_correction.Clear;

        frag.FrgReset;
        frag.MolToFrgLst(mol_correction_arom);
        totfraglst := frag.GetFrgLst;

        FreeAndNil(mol_correction_arom);

        molList.Add(LRDsc.Create);
        mol_data := molList.Last as LRDsc;
        LRDsc_creation(totfraglst, mol_data);
      end;

      FreeAndNil(mol_correction);

      // Getting the scaffold from the JSON
      smol_scaffold := Copy(Parser.Find('scaffold/scaffold').Value, 2, Length(Parser.Find('scaffold/scaffold').Value) - 2);
      if (smol_scaffold <> '') then
      begin
        mol_scaffold := TStringList.Create;
        mol_scaffold.Text := StringReplace(smol_scaffold, '\n', Lineending,
          [rfReplaceAll, rfIgnoreCase]); // From string to Tstringlist

        mol_scaffold_arom := aromatize_lp(mol_scaffold);

        frag.FrgReset; // purge le fragmentor des fragments générés pour la molécule précédente.
        frag.MolToFrgLst(mol_scaffold_arom);  // Take the molfile and generates the fragments. Dictionnaire mot qui décrit le frg et pointeur vers une valeur
        totfraglst := frag.GetFrgLst;   // A row of the descriptor matrix

        molList.Add(LRDsc.Create);     // Contains the LRDsc objects
        mol_data := molList.Last as LRDsc;
        LRDsc_creation(totfraglst, mol_data);
        FreeAndNil(mol_scaffold);
        FreeAndNil(mol_scaffold_arom);
      end;
    // Grading the two molecules.
      // The method of calculation is given ( 1: Euclidian, 2: Tanimoto, 3: RBF, 4: CosKern) euc: 1 - EncDist/dmax
      // (dmax calculé sur l'ensemble des réponses pour cette question, mais peut aussi être calculé en fonction de la réponse du prof, et si on a des valeurs négatives, note:=0)
      // molList.WriteSVM('test.svm', 'test.hdr');
      molList.metric := 2;
      noteMax:= 0;
      molMax:=1;

      for I:= 1 to nbCorrection do
      begin
        note := molList.CompareElements(0, I);
        if (note > noteMax) then
        begin
          noteMax:= note;
          molMax:= I;
        end;
      end;
      note := noteMax;

      // Calculate grade between scaffold and molteacherMax

      if (smol_scaffold <> '') then
      begin
        noteScaffold:=molList.CompareElements(I, nbCorrection+1);
        if noteScaffold < 1 then
        begin
          note := (noteMax - noteScaffold)/(1-noteScaffold);
        end;
        if (note < 0) then note := 0;
      end;

      // We check if there is stereo in the molecule, and change the grade accordingly

      sStereo := Parser.Find('stereoopt/opt').Value.Replace('"', '', [rfReplaceAll]);
      suniqueid:= Parser.Find('attemptid/id').Value.Replace('"', '', [rfReplaceAll]);;

      if (sStereo = '1') then
      begin
        if (note = 1) then
          begin
            // Need to remove the lone pairs because inchi doesn't recognize them
            smol_correction := Parser.Find('correction/mol_' + IntToStr(molMax)).Value;
            mol_correction := TStringList.Create;
            mol_correction.Text := StringReplace(smol_correction, '\n',
                Lineending, [rfReplaceAll, rfIgnoreCase]);

            mol_correction_arom := aromatize_lp(mol_correction);

            Strip_LP(mol_student_arom);
            Strip_LP(mol_correction_arom);

            stereo_student := add_Stereo(mol_student_arom, suniqueid);
            stereo_correction := add_Stereo(mol_correction_arom, suniqueid);
            stereo_counter:=0;
            max_stereo:=0;
            if (stereo_correction.bond_stereo <> Nil) then
              begin
                max_stereo:= Length(stereo_correction.bond_stereo);
                for I := Low(stereo_correction.bond_stereo) to High(stereo_correction.bond_stereo) do
                begin
                  if (CompareText(stereo_correction.bond_stereo[I], stereo_student.bond_stereo[I]) = 0) then stereo_counter := stereo_counter+1;
                end;
              end;

            if (stereo_correction.atom_stereo <> Nil) then
              begin
                max_stereo:= max_stereo + Length(stereo_correction.atom_stereo);
                for I := Low(stereo_correction.atom_stereo) to High(stereo_correction.atom_stereo) do
                  begin
                    if (CompareText(stereo_correction.atom_stereo[I], stereo_student.atom_stereo[I]) = 0) then stereo_counter := stereo_counter+1;     //prb if no stereo from student
                  end;
              end;

            if (max_stereo>0) then                       // If note = 1, stereo is asked but there is no stereo in the molecule, the note is still equal to 1
              note := note * (stereo_counter/max_stereo);

          // If notescaffold = 1 and stereo asked, we check for the stereo of the scaffold to modify the grade
          if (noteScaffold = 1) then
            begin
              mol_scaffold := TStringList.Create;
              mol_scaffold.Text := StringReplace(smol_scaffold, '\n', Lineending,
              [rfReplaceAll, rfIgnoreCase]); // From string to Tstringlist

              mol_scaffold_arom := aromatize_lp(mol_scaffold);
              Strip_LP(mol_scaffold_arom);
              stereo_student := add_Stereo(mol_scaffold_arom, suniqueid);

              stereo_counter:=0;
              max_stereo:=0;
              if (stereo_correction.bond_stereo <> Nil) then
                begin
                  max_stereo:= Length(stereo_correction.bond_stereo);
                  for I := Low(stereo_correction.bond_stereo) to High(stereo_correction.bond_stereo) do
                  begin
                    if (CompareText(stereo_correction.bond_stereo[I], stereo_student.bond_stereo[I]) = 0) then stereo_counter := stereo_counter+1;
                  end;
                end;

              if (stereo_correction.atom_stereo <> Nil) then
                begin
                  max_stereo:= max_stereo + Length(stereo_correction.atom_stereo);
                  for I := Low(stereo_correction.atom_stereo) to High(stereo_correction.atom_stereo) do
                    begin
                      if (CompareText(stereo_correction.atom_stereo[I], stereo_student.atom_stereo[I]) = 0) then stereo_counter := stereo_counter+1;     //prb if no stereo from student
                    end;
                end;

              if (max_stereo>0) then                       // If note = 1, stereo is asked but there is no stereo in the molecule, the note is still equal to 1
                noteScaffold := 1 * (stereo_counter/max_stereo);


              if noteScaffold < 1 then
              begin
                note := (note - noteScaffold)/(1-noteScaffold);
              end;
              if (note < 0) then note := 0;

              FreeAndNil(mol_scaffold);
              FreeAndNil(mol_scaffold_arom);
            end;
          FreeAndNil(mol_correction);
          FreeAndNil(mol_correction_arom);
          end
          else note:=0;
      end;
    end;

    // Grade added to the Json

    if IsNan(note) then
    begin
      Parser := Parser.Find('student');
      Parser.Add('grade', 0);
      Parser := Parser.Root;
    end
    else
    begin
      Parser := Parser.Find('student');
      Parser.Add('grade', note);
      Parser := Parser.Root;
    end;

    begin
      {jObject.Strings['answer'] :=
        'The answer is: ' + molList.SMFv2toStrList().CommaText + ', ' + note.ToString + Parser.Value;
      res.Content := jObject.AsJSON; // ou
  For I := 1 to High(Row) do
    Temp := Temp + Row[i];
  Average := Temp / (High(Row)+1);
end; tput the data as a JSON formatted string
      jsonResponse(res, jObject.AsJSON);}
      res.Content := Parser.Value;
      httpCode:= 200;
      jsonResponse(res, Parser.Value, httpCode);
    end;

    // free et valeur == nulle
    FreeAndNil(molList);
    FreeAndNil(Parser);
    FreeAndNil(frag);
    FreeAndNil(mol_student_arom);
    //Application.Terminate; Force termination of the service
  end;
// Set up the server application.

begin
  //WriteLn('Got ', ParamCount, ' command line parameters.');
  SubstrPort:='--Port=';
  For i:=1 to ParamCount do
      begin
      //WriteLn(ParamStr(i));
      if (ParamStr(i) = '--JWTNEEDED') then
      begin
        WriteLn('JWT Being used');
        textJWT:='Yes';
      end;

      if (Pos(SubstrPort, ParamStr(i)) > 0) then
      begin
      textPort:='Yes';
      Portnb:= StringReplace(ParamStr(i), '--Port=', '', []);
      WriteLn('Port used: ',StringReplace(ParamStr(i), '--Port=', '', []));
      end;
      end;

  if (textJWT <> 'Yes') then
  begin
    WriteLn('JWT not used. If you want to use JWT security, please use "rest_api_multi --JWTNEEDED".');
  end;
  if (textPort <> 'Yes') then
  begin
    WriteLn('Default port used. If you want to parameter the port, please use "--Port=".');
  end;

  try
    // Variable can be set by the user
    Application.Port := StrToInt(Portnb);
  except
    On E : EConvertError do
    Application.Port := 9080;
  end;

  HTTPRouter.RegisterRoute('/time', @timeEndpoint, True);
  HTTPRouter.RegisterRoute('/isida', @ISIDA);
  HTTPRouter.RegisterRoute('/greeting/:name', @greetingEndpoint);
  Application.Threaded := True;
  Application.Initialize;
  WriteLn(format('API is ready at http://localhost:%d/', [Application.Port]));
  Application.Run;
end.
