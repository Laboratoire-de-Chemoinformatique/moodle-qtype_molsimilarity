{ Rest server of the molsimilarity Moodle Plugin (https://github.com/Laboratoire-de-Chemoinformatique/moodle-qtype_molsimilarity)

  Copyright (C) 2023 Laboratoire de Chemoinformatique, UMR 7140 CNRS (http://infochim.u-strasbg.fr/)
  contact: Gilles Marcou g.marcou@unistra.fr

  This source is free software; you can redistribute it and/or modify it under
  the terms of the GNU Lesser General Public License as published by the Free
  Software Foundation; either version 3 of the License, or (at your option)
  any later version.

  This code is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
  details.

  A copy of the GNU General Public License is available on the World Wide Web
  at <http://www.gnu.org/copyleft/gpl.html>. You can also obtain it by writing
  to the Free Software Foundation, Inc., 51 Franklin Street - Fifth Floor,
  Boston, MA 02110-1335, USA.
}

unit unit_api_tools;
// this unit contains the tools used for the rest_api

{$mode objfpc}{$H+}

interface

uses
  Classes,
  SysUtils,
  Process,
  strutils,
  ISIDA_descriptor,
  unitIndigo;

type record_output = record
  atom_stereo: array of String;
  bond_stereo: array of String;
end;

procedure LRDsc_creation(fraglist: TStringList; var mol: LRDsc);

procedure Strip_LP(molfile: TStringList);
function LP_aromatize_reac(RxnFile: TStringList): TStringList;
function aromatize_lp(molfile: TStringList): TStringList;

function add_Stereo(mol: TStringList; id: string):record_output;
function add_StereoUnc(mol: TStringList; id: string): record_output;

implementation

procedure Strip_LP(molfile: TStringList);
var
  fmt, sCount_line, nb_atom_final, nb_bond_final: String;
  i, j, iNb_LP: integer;
  count_line : array of string;

begin
  count_line:= molfile[3].Split([' '], TStringSplitOptions.ExcludeEmpty);
  iNb_LP:=0;
  for i:=(molfile.Count -1) downto 2  do
  begin
    if (pos('LP', molfile[i]) <> 0) then      // If lone pair located, we delete the line in the bond block
      begin
        iNb_LP := iNb_LP+1 ;
        molfile.Delete(i);
      end;
  end;

  if iNb_LP >=1 then   // Get the number of lone pairs removed, if equal to 0, nothing is done, otherwise we modify the molfile
    begin
      fmt:='%3s';
      nb_atom_final:=Format(fmt, [IntToStr(StrToInt(count_line[0])-iNb_LP)]);      // Modification of the count line
      nb_bond_final:=Format(fmt, [IntToStr(StrToInt(count_line[1])-iNb_LP)]);

      sCount_line:='';
      sCount_line:= sCount_line+nb_atom_final+nb_bond_final+ Copy(molfile[3], 7) ;
      molfile[3]:=sCount_line;

      for j:=0 to iNb_LP-1 do        // Remove the lone pairs bonds
        begin
          molfile.Delete(molfile.Count-2);
        end;
    end;
      //test := molfile.Text;
end;

function aromatize_lp(molfile: TStringList): TStringList;
var
  fmt, sCount_line, nb_atom_final, nb_bond_final, count_line_cpy: String;
  i, j, iNb_LP: integer;
  count_line : array of string;
  idlines: array of Integer;
  lines, lines_bd: TStringList;
begin
  Result:=TStringList.Create;

  count_line_cpy := molfile[3];
  count_line:= molfile[3].Split([' '], TStringSplitOptions.ExcludeEmpty);
  lines := TStringList.Create;
  lines_bd := TStringList.Create;

  iNb_LP:=0;
  for i:=2 to (molfile.Count -1) do
  begin
   if (pos('LP', molfile[i]) <> 0) then
     begin
       iNb_LP := iNb_LP+1;
     end;
  end;

  SetLength(idlines, iNb_LP);

  for i:=2 to (molfile.Count -1) do
  begin
   if (pos('LP', molfile[i]) <> 0) then      // Look for the number of lone pairs in the molfile, add the atoms block lines to lines, and the line number to idlines
     begin
       lines.Add(molfile[i]);
       idlines[lines.Count -1] := i;
     end;
  end;

  if iNb_LP >= 1 then
  begin
   for i:=(molfile.Count -1) downto 2  do
   begin
     if (pos('LP', molfile[i]) <> 0) then      // If lone pair located, we delete the line in the bond block
       begin
         molfile.Delete(i);
       end;
   end;

   // Get the number of lone pairs removed, in order to modify the count line

   fmt:='%3s';
   nb_atom_final:=Format(fmt, [IntToStr(StrToInt(count_line[0])-iNb_LP)]);      // Modification of the count line
   nb_bond_final:=Format(fmt, [IntToStr(StrToInt(count_line[1])-iNb_LP)]);

   sCount_line:='';
   sCount_line:= sCount_line+nb_atom_final+nb_bond_final+ Copy(molfile[3], 7) ;
   molfile[3]:=sCount_line;

   for j:=0 to iNb_LP-1 do        // Remove the lone pairs bonds
     begin
       lines_bd.Add(molfile[molfile.Count-2]);
       molfile.Delete(molfile.Count-2);
     end;
  end;

  // Aromatize
  Result := AromFromTStringList(molfile);

  // Put back the LP
  if iNb_LP >= 1 then
  begin
   Result[3] := count_line_cpy;
   for i:=0 to lines.Count-1 do
   begin
     Result.Insert(idlines[i], lines[i]);
     Result.Insert(molfile.Count+2*i, lines_bd[lines_bd.Count - (i+1)]); // In molfile.Count in case some fields were added by indigo, +2*i because each iteration we add two fields in result
   end;
  end;

  FreeAndNil(lines);
  FreeAndNil(lines_bd);
end;


//Takes a rxn file as a tstringlist as input. For each molecule: removes the LP,
//aromatizes it, and add back the LP.
//Carefull, creates the tstringlist, you will need to dispose of it.
function LP_aromatize_reac(RxnFile: TStringList): TStringList;
var
  LineNo, nbProd, nbReact, i, j: integer;
  ReacName: String;
  count_line : array of string;
  mol, mol_arom: TStringList;

begin
  Result := TStringList.Create;
  //Read each line and create the base molecules
  LineNo  := 0;
  Result.Add(RxnFile[LineNo]);
  //---Line 1 : $RXN in the first position on this line identifies the file as a reaction file---
  Inc(LineNo);
  Result.Add(RxnFile[LineNo]);
  //---Line 2 : Reaction name---
  ReacName := RxnFile[LineNo];
  //---Line 3 of RxnFile---
  //  User's first and last initials (UserI), program name (ProgN), date/time:
  //  M/D/Y,H:m (DatTim), dimensional codes (DimCo), scaling factors (ScaI, ScaR),
  //  energy (Ene) if modeling program input, internal registry number (RegNo)
  //  if input through MDL format:
  Inc(LineNo);
  Result.Add(RxnFile[LineNo]);
  //---Line 4 of RxnFile---
  // A line for comments. If no comment is entered, a blank line must be present.
  Inc(LineNo);
  Result.Add(RxnFile[LineNo]);
  //---Line 5 of RxnFile : A line identifying the number of reactants and products, in that order.---
  //  We get the number of React and Prod
  Inc(LineNo);
  Result.Add(RxnFile[LineNo]);
  count_line := RxnFile[LineNo].Split([' '], TStringSplitOptions.ExcludeEmpty);
  nbReact := StrToInt(count_line[0]);
  nbProd := StrToInt(count_line[1]);


 // Reacts
  mol := TStringList.Create;
  for i := 1 to nbReact do
  begin
    // $MOL
    Inc(LineNo);
    Result.Add(RxnFile[LineNo]);

    // Molfile
    while (RxnFile[LineNo] <> 'M  END') do
    begin
      Inc(LineNo);
      mol.Add(RxnFile[LineNo]);
    end;

    // Aromatize it taking care of LP
    mol_arom := aromatize_lp(mol);

    //Add the mol to the result
    for j:=0 to mol_arom.Count-1 do
    begin
      Result.Add(mol_arom.Strings[j]);
    end;
    mol.Clear;
    FreeAndNil(mol_arom);
  end;

  // Products
  for i := 1 to nbProd do
  begin
    // $MOL
    Inc(LineNo);
    Result.Add(RxnFile[LineNo]);

    // Molfile
    while (RxnFile[LineNo] <> 'M  END') do
    begin
      Inc(LineNo);
      mol.Add(RxnFile[LineNo]);
    end;

    // Aromatize it taking care of LP
    mol_arom := aromatize_lp(mol);

    //Add the mol to the result
    for j:=0 to mol_arom.Count-1 do
    begin
      Result.Add(mol_arom.Strings[j]);
    end;

    mol.Clear;
    FreeAndNil(mol_arom);
  end;

  FreeAndNil(mol);
end;

procedure LRDsc_creation(fraglist: TStringList;  var mol: LRDsc);
 {Takes a fragmented molecule, and create a LRDsc}
var
  i: integer;
  desc: RDsc;
begin
  for i := 0 to fraglist.Count -1 do
  begin
    with desc do
    begin
     Nme := fraglist[i];
     Idx := i + 1;
     Cnt := PInteger(fraglist.Objects[i])^;
    end;
    mol.Add(desc);
  end;
end;

function add_Stereo(mol: TStringList; id: string): record_output; // Takes the given molfile, writes it, launch the inchi exe, collect the inchi code from it, select the stereo part and add it at the end of the molfile
const
  INCHI_linux = 'inchi-1 ';
  INCHI_exe = 'inchi-1.exe ';
  dir_stock = 'temp_stock';
  logFile = 'errors_log.txt';
var
  fStdProc: TProcess;
  time, name_of_file, b_block, t_block, m_block: String;
  inchi: TStringList;
  idb, idt, idm, ids: SizeInt;
  record_output_1: record_output;
  l: Text;

begin

  {Tetrahedral parity is ‘+’ if the canonical numbers of neighbors increase
    clockwise when observed from a hydrogen atom or an atom that has the smallest canonical
    41number; parity of a double bond is ‘-’ if neighbors with greater canonical numbers are located
    on the same side of the bond.
  }
  // Creation of the random name of the file
  Randomize; // Generating a new sequence each time the procedure is used.
  time := FormatDateTime('yy-mm-dd-hh-nn-ss', now);
  name_of_file := GetCurrentDir+PathDelim+dir_stock+PathDelim+time+id+'-'+IntToStr(Random(1000));
  mol.SaveToFile(name_of_file);

  // Creation of the INCHI using inchi-1

  fStdProc := TProcess.Create(nil);
  fStdProc.Options:=fStdProc.Options + [poWaitOnExit];
  {$IFDEF WIN64}
    fStdProc.CommandLine := GetCurrentDir +PathDelim+ INCHI_exe + name_of_file +' /Tabbed /NoLabels /AuxNone /SUU';
  {$ENDIF}
  {$IFDEF LINUX}
    fStdProc.CommandLine := GetCurrentDir +PathDelim+ INCHI_linux + name_of_file +' -Tabbed -NoLabels -AuxNone -SUU';
  {$ENDIF}
  fStdProc.Execute;
  FreeAndNil(fStdProc);
  //fStdProc.Free;

  // Retrieving the INCHI from name_of_file+'.txt'

  inchi := TStringList.Create;
  inchi.LoadFromFile(name_of_file+'.txt');

  // Look for the stereo fields

  idb:= Pos('/b', inchi[0]);
  idt:= Pos('/t', inchi[0]);
  idm:= Pos('/m', inchi[0]);
  ids:= Pos('/s', inchi[0]);

  if (idb >= 1) then
  begin
    if (idt >= 1) then
       begin
         b_block:= Copy(inchi[0], idb+2, (idt - idb -2));
       end
    else
      b_block:= Copy(inchi[0], idb+2, (Length(inchi[0]) - idb));
  end;
  if (idt >= 1) then
    begin
      if (idm >=1 ) then
        begin
          t_block:= Copy(inchi[0], idt+2, (idm -idt -2));
          if (ids >= 1) then m_block:= Copy(inchi[0], idm+2, (ids - idm -2))
          else m_block:= Copy(inchi[0], idm+2, (Length(inchi[0]) -idm));
        end
      else
        begin
          t_block:= Copy(inchi[0], idt+2, Length(inchi[0]));
        end;
    end;

  //if m_block is present, we use it to derive the sterochemistry of each centers  (if m1 invert + and -)
  if (Length(m_block) <> 0) then
    begin
      if (m_block[1] = '1') then
        begin
          t_block:= StringsReplace(t_block, ['+','-'], ['-','+'], [rfReplaceAll]);
        end;
    end;

  // Add the fields to the molfile and create the output

  if (Length(b_block) <> 0) then
    begin
      mol.Add('> <Stereo_E_Z>');
      mol.Add(b_block);
      record_output_1.bond_stereo := b_block.Split(',');
    end
  else
    begin
      record_output_1.bond_stereo:= Nil;
    end;
  if (Length(t_block) <> 0) then
    begin
      mol.Add('> <Stereo_S_R>');
      mol.Add(t_block);
      record_output_1.atom_stereo := t_block.Split(',');
    end
  else
    begin
      record_output_1.atom_stereo:= Nil;
    end;

  // Free memory and delete files
  If (FileExists(name_of_file)) then DeleteFile(name_of_file);
  If (FileExists(name_of_file+'.txt')) then DeleteFile(name_of_file+'.txt');
  If (FileExists(name_of_file+'.log')) then DeleteFile(name_of_file+'.log');
  If (FileExists(name_of_file+'.prb')) then DeleteFile(name_of_file+'.prb');

  //mol.SaveToFile('lepetittest.txt'); //test purpose

  Result:=record_output_1;

  FreeAndNil(inchi);

end;

function add_StereoUnc(mol: TStringList; id: string): record_output; // Takes the given molfile, writes it, launch the inchi exe, collect the inchi code from it, select the stereo part and add it at the end of the molfile
const
  INCHI_linux = 'inchi-1 ';
  INCHI_exe = 'inchi-1.exe ';
  dir_stock = 'temp_stock';
  logFile = 'errors_log.txt';
var
  fStdProc: TProcess;
  time, name_of_file, b_block, m_block: String;
  inchi: TStringList;
  idb, idt, idm, ids: SizeInt;
  record_output_1: record_output;
  t_block: array of String;
  I : LongInt;

begin

  { Tetrahedral parity is ‘+’ if the canonical numbers of neighbors increase
    clockwise when observed from a hydrogen atom or an atom that has the smallest canonical
    number; parity of a double bond is ‘-’ if neighbors with greater canonical numbers are located
    on the same side of the bond. InChI considers both enantiomers and selects the one that has the “smaller” identifier. /m0
    signifies that the selected one has exactly the same stereo arrangement as the input structure;
    /m1 means that the selected one has the inverse arrangement
  }
  // Creation of the random name of the file
  Randomize; // Generating a new sequence each time the procedure is used.
  time := FormatDateTime('yy-mm-dd-hh-nn-ss', now);
  name_of_file := GetCurrentDir+PathDelim+dir_stock+PathDelim+time+id+'-'+IntToStr(Random(1000));
  mol.SaveToFile(name_of_file);

  // Creation of the INCHI using inchi-1

  fStdProc := TProcess.Create(nil);
  fStdProc.Options:=fStdProc.Options + [poWaitOnExit];
  {$IFDEF WIN64}
    fStdProc.CommandLine := GetCurrentDir +PathDelim+ INCHI_exe + name_of_file +' /Tabbed /NoLabels /AuxNone /SUU';
  {$ENDIF}
  {$IFDEF LINUX}
    fStdProc.CommandLine := GetCurrentDir +PathDelim+ INCHI_linux + name_of_file +' -Tabbed -NoLabels -AuxNone -SUU';
  {$ENDIF}
  fStdProc.Execute;
  FreeAndNil(fStdProc);
  //fStdProc.Free;

  // Retrieving the INCHI from name_of_file+'.txt'

  inchi := TStringList.Create;
  inchi.LoadFromFile(name_of_file+'.txt');

  // Look for the stereo fields

  idb:= Pos('/b', inchi[0]);
  idt:= Pos('/t', inchi[0]);
  idm:= Pos('/m', inchi[0]);
  ids:= Pos('/s', inchi[0]);

  if (idb >= 1) then
  begin
    if (idt >= 1) then
      begin
        b_block := Copy(inchi[0], idb+2, (idt - idb -2));
      end
    else
      b_block := Copy(inchi[0], idb+2, (Length(inchi[0]) - idb));
  end;
  if (idt >= 1) then
    begin
      if (idm >=1 ) then
        begin
          t_block:= Copy(inchi[0], idt+2, (idm -idt -2)).Split(';');
          if (ids >= 1) then m_block:= Copy(inchi[0], idm+2, (ids - idm -2))
          else m_block:= Copy(inchi[0], idm+2, (Length(inchi[0]) -idm));
        end
      else
        begin
          t_block:= Copy(inchi[0], idt+2, Length(inchi[0])).Split(';', TStringSplitOptions.ExcludeEmpty);
        end;
    end;

  //if m_block is present, we use it to derive the sterochemistry of each centers  (if m1 invert + and -)
  if (Length(m_block) <> 0) then
    begin
      for I := Low(t_block) to High(t_block) do
      begin
        if (m_block[I+1] = '1') then
        begin
          t_block[I]:= StringsReplace(t_block[I], ['+','-'], ['-','+'], [rfReplaceAll]);
        end;
      end;
    end;

  // Add the fields to the molfile and create the output

  if (Length(b_block) <> 0) then
    begin
      mol.Add('> <Stereo_E_Z>');
      mol.Add(b_block);
      record_output_1.bond_stereo := b_block.Split([';', ','], TStringSplitOptions.ExcludeEmpty);
    end
  else
    begin
      record_output_1.bond_stereo:= Nil;
    end;
  if (Length(t_block) <> 0) then
    begin
      mol.Add('> <Stereo_S_R>');
      for I := Low(t_block) to High(t_block) do mol.Add(t_block[I]);
      record_output_1.atom_stereo := t_block;
    end
  else
    begin
      record_output_1.atom_stereo:= Nil;
    end;

  // Free memory and delete files
  If (FileExists(name_of_file)) then DeleteFile(name_of_file);
  If (FileExists(name_of_file+'.txt')) then DeleteFile(name_of_file+'.txt');
  If (FileExists(name_of_file+'.log')) then DeleteFile(name_of_file+'.log');
  If (FileExists(name_of_file+'.prb')) then DeleteFile(name_of_file+'.prb');

  //mol.SaveToFile('lepetittest.txt'); //test purpose

  Result:=record_output_1;

  FreeAndNil(inchi);

end;

end.

